import java.util.Scanner;

class Triangle {
    private double a, b, c;

    public Triangle(double a, double b, double c) throws InvalidTriangleException {
        if (a <= 0 || b <= 0 || c <= 0) {
            throw new InvalidTriangleException("边长必须为正数");
        }
        if (a + b <= c || a + c <= b || b + c <= a) {
            throw new InvalidTriangleException("不满足三角形不等式");
        }
        this.a = a;
        this.b = b;
        this.c = c;
    }

    public double calculateArea() {
        double s = (a + b + c) / 2;
        return Math.sqrt(s * (s - a) * (s - b) * (s - c));
    }
}

public class TriangleTester {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double a, b, c;

        try {
            System.out.print("请输入第一条边: ");
            a = scanner.nextDouble();
            System.out.print("请输入第二条边: ");
            b = scanner.nextDouble();
            System.out.print("请输入第三条边: ");
            c = scanner.nextDouble();

            Triangle triangle = new Triangle(a, b, c);
            double area = triangle.calculateArea();
            System.out.printf("三角形面积为: %.2f", area);
        } catch (InvalidTriangleException e) {
            System.out.println("错误: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("输入错误: " + e.getMessage());
        } finally {
            scanner.close();
        }
    }
}